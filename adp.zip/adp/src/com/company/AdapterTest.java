package com.company;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;



class AdapterTest {

    @org.junit.jupiter.api.Test


    @Test
    public void playMusic() {
        assertEquals("Mp4", "Mp4");
        assertEquals("vlc", "vlc");
    }
}