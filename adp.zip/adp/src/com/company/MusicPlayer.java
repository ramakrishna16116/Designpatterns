package com.company;

public interface MusicPlayer {
    void playMusic(String audioType, String fileName);
}
